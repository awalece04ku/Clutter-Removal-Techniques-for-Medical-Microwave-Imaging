close all
% List of .fig files, use case_1, case_2,...
fileNames = {'diff_sub_case_1.fig', 'avg_sub_case_1.fig', 'adj_sub_case_1.fig', ...
             'sym_sub_case_1.fig', 'emd_case_1.fig', 'svd_case_1.fig', ...
             'sf_case_1.fig', 'entropy_win_case_1.fig', 'entropy_wiener_case_1.fig', ...
             'ica_case_1.fig'};

% Directory to save JPEG files
outputDir = 'output_jpegs';
if ~exist(outputDir, 'dir')
    mkdir(outputDir); % Create directory if it doesn't exist
end

% Loop through each file
for i = 1:length(fileNames)
    % Load the .fig file
    figHandle = openfig(fileNames{i}, 'visible'); % Open the figure visibly
    
    % Generate output file name for JPEG
    [~, name, ~] = fileparts(fileNames{i});
    outputFile = fullfile(outputDir, [name, '.png']);
    
    % Save the figure as a JPEG with 600 DPI using exportgraphics
    exportgraphics(figHandle, outputFile, 'Resolution', 600);
    
    % Pause to allow viewing
    pause; % Wait for the user to press a key before continuing
    
    % Close the figure before loading the next one
    close(figHandle);
end
